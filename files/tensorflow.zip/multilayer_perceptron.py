#!/usr/bin/env python3

from os import path

import matplotlib as mpl
import numpy as np
import pandas as pd
import tensorflow as tf


M = 200
H = 100

# Create Variables
x_1 = tf.placeholder("float", None)
x_2 = tf.placeholder("float", None)
y = tf.placeholder("float", None)
np.random.seed(1)
theta = tf.Variable(np.random.randn(2, 3, 4).astype(np.float32))

# Formulate Functions
a_1 = tf.sigmoid(theta[0,0,0] + theta[0,0,1] * x_1 + theta[0,0,2] * x_2)
a_2 = tf.sigmoid(theta[0,1,0] + theta[0,1,1] * x_1 + theta[0,1,2] * x_2)
a_3 = tf.sigmoid(theta[0,2,0] + theta[0,2,1] * x_1 + theta[0,2,2] * x_2)
hypothesis = tf.sigmoid(theta[1,0,0] + theta[1,0,1] * a_1 + theta[1,0,2] * a_2 + theta[1,0,3] * a_3)
cost = (-1/M) * tf.reduce_sum(y * tf.log(hypothesis) + (1-y) * tf.log(1-hypothesis))
opt = tf.train.GradientDescentOptimizer(0.01).minimize(cost)

# Load Data
class_1 = pd.read_csv(path.join('data', 'perceptron_1.csv'), names=['X1', 'X2'], header=0)
class_2 = pd.read_csv(path.join('data', 'perceptron_2.csv'), names=['X1', 'X2'], header=0)
train = pd.concat([class_1[:H], class_2[:H]], ignore_index=True)
train['Y'] = pd.concat([pd.Series(np.zeros(H)), pd.Series(np.ones(H))], ignore_index=True)
print(train.head())
print(train.tail())

# Learn Parameters
with tf.Session() as session:
	session.run(tf.global_variables_initializer())
	for i in range(100000):
		session.run([opt, cost], feed_dict={x_1: train.X1, x_2: train.X2, y: train.Y})
		if i % 5000 == 0: print('.', end='', flush=True)
	
	t_learned = session.run(theta)
	xx1 = np.arange(train.X1.min()-0.3, train.X1.max()+0.3, 0.1)
	xx2 = np.arange(train.X2.min()-0.3, train.X2.max()+0.3, 0.1)
	xx1, xx2 = np.meshgrid(xx1, xx2)
	z = session.run(hypothesis, feed_dict={x_1: xx1, x_2: xx2})

# Print Result
print('\nHidden Layer: {}, {}, {}'.format(t_learned[0,0,:3], t_learned[0,1,:3], t_learned[0,2,:3]))
print('Output Layer: {}'.format(t_learned[1,0,:]))

# Draw Plot
mpl.use('Agg')
import matplotlib.pyplot as pypl
pypl.plot(train[train.Y == 0].X1, train[train.Y == 0].X2, 'ro')
pypl.plot(train[train.Y == 1].X1, train[train.Y == 1].X2, 'bo')
pypl.contour(xx1, xx2, z.reshape(xx1.shape), cmap=pypl.cm.Paired, alpha=0.5)
pypl.savefig('./multilayer_perceptron.png')
