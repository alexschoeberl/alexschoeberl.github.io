#!/usr/bin/env python3

from os import path

import matplotlib as mpl
import numpy as np
import pandas as pd
import tensorflow as tf


M = 200
H = 100

# Create Variables
x_1 = tf.placeholder("float", None)
x_2 = tf.placeholder("float", None)
y = tf.placeholder("float", None)
theta_0 = tf.Variable(.0)
theta_1 = tf.Variable(.0)
theta_2 = tf.Variable(.0)

# Formulate Functions
boundary = theta_0 + theta_1 * x_1 + theta_2 * x_2
hypothesis = tf.sigmoid(boundary)
cost = (-1/M) * tf.reduce_sum(y * tf.log(hypothesis) + (1-y) * tf.log(1-hypothesis))
opt = tf.train.GradientDescentOptimizer(0.01).minimize(cost)

# Load Data
class_1 = pd.read_csv(path.join('data', 'logistic_1.csv'), names=['X1', 'X2'], header=0)
class_2 = pd.read_csv(path.join('data', 'logistic_2.csv'), names=['X1', 'X2'], header=0)
train = pd.concat([class_1[:H], class_2[:H]], ignore_index=True)
train['Y'] = pd.concat([pd.Series(np.zeros(H)), pd.Series(np.ones(H))], ignore_index=True)
print(train.head())
print(train.tail())

# Learn Parameters
with tf.Session() as session:
	session.run(tf.global_variables_initializer())
	for i in range(15000):
		session.run([opt, cost], feed_dict={x_1: train.X1, x_2: train.X2, y: train.Y})
	t0_learned = session.run(theta_0)
	t1_learned = session.run(theta_1)
	t2_learned = session.run(theta_2)

# Print Result
print('t = {} + {} * x_1 + {} * x_2'.format(t0_learned, t1_learned, t2_learned))

# Draw Plot
mpl.use('Agg')
import matplotlib.pyplot as pypl
pypl.plot(train[train.Y == 0].X1, train[train.Y == 0].X2, 'ro')
pypl.plot(train[train.Y == 1].X1, train[train.Y == 1].X2, 'bo')
points = np.array([0, 4])
pypl.plot(points, -((t0_learned + t1_learned * points) / t2_learned))
pypl.savefig('./logistic_regression.png')
