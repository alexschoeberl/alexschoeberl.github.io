#!/usr/bin/env python3

from os import path

import matplotlib as mpl
import pandas as pd
import tensorflow as tf


M = 100

# Create Variables
x = tf.placeholder("float", None)
y = tf.placeholder("float", None)
theta_0 = tf.Variable(.0)
theta_1 = tf.Variable(.0)

# Formulate Functions
hypothesis = theta_0 + theta_1 * x
cost = (1/(2*M)) * tf.reduce_sum((hypothesis - y)**2)
opt = tf.train.GradientDescentOptimizer(0.01).minimize(cost)

# Load Data
df = pd.read_csv(path.join('data', 'linear.csv'), names=['X', 'Y'], header=0)
train = df[:M]
print(train.head())

# Learn Parameters
with tf.Session() as session:
	session.run(tf.global_variables_initializer())
	for i in range(5000):
		session.run([opt, cost], feed_dict={x: train.X, y: train.Y})
	t0_learned = session.run(theta_0)
	t1_learned = session.run(theta_1)

# Print Result
print('y = {} + {} * x'.format(t0_learned, t1_learned))

# Draw Plot
mpl.use('Agg')
import matplotlib.pyplot as pypl
pypl.plot(train.X, train.Y, 'ro')
pypl.plot(train.X, t0_learned + t1_learned * train['X'])
pypl.savefig('./linear_regression.png')
